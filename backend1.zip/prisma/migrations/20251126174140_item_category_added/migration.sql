-- AlterEnum
ALTER TYPE "PostCategory" ADD VALUE 'ITEMS';
